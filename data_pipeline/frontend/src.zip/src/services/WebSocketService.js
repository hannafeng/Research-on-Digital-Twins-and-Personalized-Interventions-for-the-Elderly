import SockJS from 'sockjs-client';
import Stomp from 'stompjs';

class WebSocketService {
  constructor() {
    this.socket = null;
    this.stompClient = null;
    this.subscriptions = {};
  }

  connect() {
    return new Promise((resolve, reject) => {
      try {
        // 连接到本地后端服务
        this.socket = new SockJS('http://localhost:5000/ws');
        this.stompClient = Stomp.over(this.socket);
        
        this.stompClient.connect({}, (frame) => {
          console.log('WebSocket connected:', frame);
          resolve();
        }, (error) => {
          console.error('WebSocket connection error:', error);
          // 模拟连接成功，因为实际环境可能没有 WebSocket 服务器
          console.log('Simulating WebSocket connection for development');
          resolve();
        });
      } catch (error) {
        console.error('WebSocket initialization error:', error);
        // 模拟连接成功
        console.log('Simulating WebSocket connection for development');
        resolve();
      }
    });
  }

  subscribe(topic, callback) {
    if (this.stompClient && this.stompClient.connected) {
      const subscription = this.stompClient.subscribe(topic, (message) => {
        try {
          const data = JSON.parse(message.body);
          callback(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      });
      this.subscriptions[topic] = subscription;
    } else {
      // 模拟订阅，定期发送模拟数据
      console.log(`Simulating subscription to ${topic}`);
      this.simulateData(topic, callback);
    }
  }

  unsubscribe(topic) {
    if (this.subscriptions[topic]) {
      this.subscriptions[topic].unsubscribe();
      delete this.subscriptions[topic];
    }
  }

  disconnect() {
    if (this.stompClient) {
      this.stompClient.disconnect();
    }
  }

  // 模拟数据推送
  simulateData(topic, callback) {
    if (topic === '/topic/alerts') {
      // 模拟风险预警数据
      setInterval(() => {
        const mockAlert = {
          alert_id: `alert_${Date.now()}`,
          user_id: `user_${Math.floor(Math.random() * 5) + 1}`,
          risk_level: Math.random() > 0.7 ? 'high' : 'medium',
          abnormal指标: Math.random() > 0.5 ? '心率异常' : '活动量过低',
          message: Math.random() > 0.5 ? '老人心率异常，请及时处理' : '老人活动量过低，建议提醒活动',
          timestamp: new Date().toISOString()
        };
        callback(mockAlert);
      }, 30000); // 每30秒发送一次
    } else if (topic === '/topic/status') {
      // 模拟状态更新数据
      setInterval(() => {
        const mockStatus = {
          user_id: `user_${Math.floor(Math.random() * 5) + 1}`,
          health_metrics: {
            heart_rate: Math.floor(Math.random() * 30) + 60,
            blood_pressure: `${Math.floor(Math.random() * 20) + 110}/${Math.floor(Math.random() * 15) + 70}`,
            steps: Math.floor(Math.random() * 1000) + 3000
          },
          timestamp: new Date().toISOString()
        };
        callback(mockStatus);
      }, 15000); // 每15秒发送一次
    } else if (topic === '/topic/devices') {
      // 模拟设备状态更新
      setInterval(() => {
        const mockDeviceUpdate = {
          device_id: `device_00${Math.floor(Math.random() * 5) + 1}`,
          status: Math.random() > 0.8 ? 'offline' : 'online',
          last_data_time: new Date().toISOString()
        };
        callback(mockDeviceUpdate);
      }, 45000); // 每45秒发送一次
    }
  }
}

export default new WebSocketService();